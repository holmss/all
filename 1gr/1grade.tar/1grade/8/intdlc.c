#include <stdio.h>
#include "dlc.h"

list *additem(list *l, int n)
{
	list *temp, *p;
	
	temp = (list*)malloc(sizeof(list));
	
	p = l->next; 
	l->next = temp; 
	temp->value = n; 
	temp->next = p; 
	temp->prev = l; 
	
	if (p != NULL)
		p->prev = temp;
	
	return(temp);
}

list *init(int n)
{
	list *node = (list*)malloc(sizeof(list));
	node->value = n;
	node->prev = NULL;
	node->next = NULL;

	return node;
}

list *rmitem(list *l, int value)
{	
	list *prev, *next;
	
	if(value != l->value)
	{
		return rmitem(l->next, value);
	}
	
	prev = l->prev;
	next = l->next; 
	
	if (prev != NULL)
		prev->next = l->next; 
		
	if (next != NULL)
		next->prev = l->prev;
	
	free(l);
	
	return prev;
}

list *rmroot (list *root)
{
	list *temp;
	
	temp = root->next;
	temp->prev = NULL;
	
	free(root);
	
	return(temp);
}

void print (const list *l)
{
	if(l == NULL){
    return;
  }
  
  printf("%d ", l->value);
  print (l->next);
  putchar('\n');
}

int amount(const list *l, list *p)
{
	int t = 1;
	
	if (p != NULL)
		t += amount(p, p->next);
	
	return t;
}

int isinorder (list *p, list *n, int inorder, int diff)
{
	int diff2;
	
	if (n != NULL)
	{
		diff2 = n->value - p->value;
		
		if (diff != diff2)
		{
			inorder = 1;
		}			
		return isinorder(p->next, n->next, inorder, diff);
	}
	
	return inorder;
}

int main()
{	
	list *root, *current;
	char q[10];
	int value;
	
	while (scanf("%s%d", q, &value) == 2)
	{
		if(q[0] == 'r')
		{
			root = init (value);
			current = root;
		}
		else if(q[0] == '+')
		{
			current = additem (current, value);
		}
		else if(q[0] == '-')
		{
			rmitem (root, value);
		}
		else if(q[0] == '#')
		{
			root = rmroot (root);
		}
		else if(q[0] == '?')
		{
			list *p = root->next;
			printf("\nLENGTH: %d\n", amount (root, p));
		}
		else if(q[0] == 'o')
		{
			list *p = root;
			list *n = root->next;
			int diff = n->value - p->value;
			printf("\nIN ORDER: %d\n", isinorder (p, n, 0, diff));
		}
		else if(q[0] == 'p')
		{
			print(root);
		}
	}

	
	return 0;
}
