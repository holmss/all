#ifndef _INT_DLC_
#define _INT_DLC_

#define true 1
#define false 0

typedef struct dlc{
	int x;
	struct dlc *next;
	struct dlc *prev;
}list;

#endif
