#include <stdio.h>
#include <stdlib.h>

typedef struct TTree{
	int value;
	struct TTree* left;
	struct TTree* right;
}Tree;

Tree* insert(Tree* tree, int value)
{
  if(tree == NULL)
  {
    Tree* newTree = (Tree*)malloc(sizeof(Tree));
    newTree->value = value;
    newTree->left = NULL;
    newTree->right = NULL;
    return newTree;
  }
  if(tree->value == value)
  {
    return tree;
  }
  if(value < tree->value)
  {
    tree->left = insert(tree->left, value);
  }
  else
  {
    tree->right = insert(tree->right, value);
  }
}

void printInorder(const Tree* tree, int tab)
{
  printInorder(tree->left, tab+2);
  for(int i = 0; i < tab; ++i)
  {
    putchar(' ');
  }
  printf("%d\n", tree->value);
  printInorder(tree->right, tab+2);
  if(tree == NULL)
  {
    return;
  }
}

bool contains(const Tree* tree, int value)
{
  if(tree == NULL)
  {
    return false;
  }
  if(tree->value == value)
  {
    return true;
  }
  if(tree->value > value)
  {
    return contains(tree->left, value);
  }
  return(tree->right, value);
}

Tree* extractMax(Tree* tree, Tree* parent)
{
  if(tree->right != NULL)
    return extractMax(tree, tree->right);
  if(tree == parent->right)
    parent->right = tree->left;
  else
    parent->left = tree->left;
  return tree;
}

Tree* erase(Tree* tree, int value)
{
  if(tree == NULL)
    return NULL;
  if(value < tree->value){
    tree->left = erase(tree->left, value);
    return tree;
  }
  else if(value > tree->value){
    tree->right = erase(tree->right, value);
    return tree;
  }
  if(tree->left == NULL)
    return tree->right;
  Tree* other = extractMax(tree->left, tree);
  tree->value = other->value;
  free(other);
  return tree;
}

int main()
{
  Tree* root = NULL;
  int value;
  chae q[10];
  while(scanf("%s%d", &value) == 2)
  {
    if(q[0] == '+')
    {
      root = insert(root, value);
      puts("------------------");
      printInorder(root, 0);
      puts("------------------");
    }else if(q[0] == '?')
    {
      if(contains(root, value))
      {
        puts("YES");
      }else{
        puts("NO");
      }
    }
    else if(q[0] == "-")
    {
      
    }
  }
  return 0;
}
