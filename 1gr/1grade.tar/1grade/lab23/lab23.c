#include <stdio.h>
#include <stdlib.h>
#include <string.h>

typedef struct TTree {
  int value;
  struct TTree* child;
  struct TTree* sibling;

} Tree;

Tree* createNode(int value) {
  Tree* node = (Tree*)malloc(sizeof(Tree));
  node->value = value;
  node->child = NULL;
  node->sibling = NULL;
  return node;
}

Tree* createRoot(int value) {
  return createNode(value);
}

Tree* addSibling(Tree* tree, int value) {
  if(tree->sibling == NULL){
    tree->sibling = createNode(value);
    return tree;
  }
  tree->sibling = addSibling(tree->sibling, value);
  return tree;
}

Tree* addChild(Tree* tree, int value) {
  if(tree->child == NULL){
    tree->child = createNode(value);
    return tree;
  }
  tree->child = addSibling(tree->child, value);
  return tree;
}

Tree* insert(Tree* tree, const char* path, int value) {
  if(*path == '\0'){
    addChild(tree, value);
    return tree;
  }
  if(*path == 'c'){
    tree->child = insert(tree->child, path + 1, value);
  }else{
    tree->sibling = insert(tree->sibling, path + 1, value);
  }
  return tree;
}

void printTree(const Tree* tree, int tab) {
  if(tree == NULL){
    return;
  }
  for(int i = 0; i < tab; ++i){
    putchar(' ');
  }
  printf("%d\n", tree->value);
  printTree(tree->child, tab + 2);
  printTree(tree->sibling, tab);
}

void eraseThis(Tree* tree) {
  if(tree == NULL){
    return;
  }
  eraseThis(tree->child);
  eraseThis(tree->sibling);
  free(tree);
}

Tree* erase(Tree* tree, const char* path) {
  if(*path == '\0'){
    eraseThis(tree->child);
    Tree* temporary = tree->sibling;
    free(tree);
    return temporary;
  }
  if(*path == 'c'){
    tree->child = erase(tree->child, path + 1);
  }else{
    tree->sibling = erase(tree->sibling, path + 1);
  }
  return tree;
}

int max(int a, int b) {
  if(a < b){
    return b;
  }
  return a;
}

int calcSiblings(const Tree* tree) {
  if(tree == NULL){
    return 0;
  }
  return calcSiblings(tree->sibling) + 1;
}

int countNextWidth(const Tree* tree, int nLvlW)
{
	if(tree != NULL)
	{
	  if(tree->child != NULL)
	  {
		  nLvlW += calcSiblings(tree->child);
		 
	  }
	  if(tree->sibling != NULL){
	 	  nLvlW += countNextWidth(tree->sibling, nLvlW);
		
	  }
	}
	printf("%d\n", nLvlW);
	return nLvlW;
}

int calcDif(const Tree* tree, int TlvlW)
{
  int NlvlW, Dif=0;
  NlvlW = countNextWidth(tree, 0);
  if(NlvlW != 0)
  {
    Dif = TlvlW - NlvlW;
    return Dif;
  }
  return -1;
}

int compareDif(const Tree* tree, int tw, int Dif1)
{
  int Dif2 = calcDif(tree, tw);
  if(Dif1 == Dif2)
	  return 0;
  else 
	  return 1;
}

int decreases(const Tree* tree, int tw, int Dif1)
{
  int f;
  if(tree != NULL)
  {
	f = compareDif(tree, tw, Dif1);
    if(f == 0)
	{
	  tw = countNextWidth(tree, 0);
	  if((tw - Dif1) != 0)
	  {
	    return compareDif(tree->child, tw, Dif1);
	  }
	}
  }
  return f;
}

/*int compareDif(Tree* tree, int Dif, int tw)
{
  if(tree != NULL)
  {
	Tree* sibl = tree;
    int Dif2 = calcDif(tree, tw);
    if(Dif2 == Dif)
    {
	  tw = countNextWidth(tree, 0);
      if(tree->child != NULL)
	  {
	    //Dif2 = calcDif(tree->child, tw);
	    Dif2 = compareDif(tree->child, Dif, tw);
	  }else if(tree->sibling != NULL)
	  {
		do{
		  sibl = tree->sibling;
		}while(sibl->child == NULL);
		//Dif2 = calcDif(sibl->child, Dif, tw);
		Dif2 = compareDif(sibl->child, Dif, tw);
	  }
	}else{
	  return 1;
	}
  }
  return 0;
}

int isSorted(const Tree* tree, const int difference1)
{
  if (tree != NULL)
  {
      int thisWidth = calcSiblings(tree);
      int nextWidth = calcSiblings(tree->child);
      int difference2 = thisWidth - nextWidth;
      if(difference2 != difference1)
	  	{
        return 1;
 	    }
  }
  return isSorted(tree->sibling);
}*/

int main() {
  Tree* root = NULL;
  int value;
  char q[10];
  int tW, dif, decr;
  while(scanf("%s%d", q, &value) == 2){
    if(q[0] == 'r'){
      root = createRoot(value);
    }else if(q[0] == '+'){
      root = insert(root, q + 1, value);
      puts("---------------");
      printTree(root, 0);
      puts("---------------");
    }else if(q[0] == '-'){
      root = erase(root, q + 1);
      puts("---------------");
      printTree(root, 0);
      puts("---------------");
    }else if(q[0] == 'k'){
		tW = countNextWidth(root, 0);
		dif = calcDif(root->child, tW);
		if(dif < 0)
		{
		  puts("WIDTH DOES NOT DECREASE MONOTONICALY");
		  return 1;
		}
		decr = decreases(root->child, dif, tW);
		if(decr == 0)
		 {
			 puts("WIDTH DECREASES MONOTONICALY!!!");
		 }else{
			 puts("WIDTH DOES NOT DECREASE MONOTONICALY");
		 }

	    	    		
      //tW = calcSiblings(root->child);
	  //nW = calcSiblings(root->child->child);
	  //diff = tW - nW;
	  //if (diff < 0)
		 // return 1;
      //IsSorted = isSorted(root->child->child, diff);
	  //if(IsSorted == 0)
	  //{
        //printf("The tree is sorted: difference is %d", diff);
	  //}else {
		//printf("The tree is not sorted");
	  //}
    }
  }
  return 0;
}
