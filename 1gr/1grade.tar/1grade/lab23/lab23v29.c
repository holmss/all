#include <stdio.h>
#include <stdlib.h>
#include <string.h>

typedef struct TTree {
  int value;
  struct TTree* left;
  struct TTree* right;

} Tree;

Tree* insert(Tree* tree, int value) {
  if(tree == NULL){
    Tree* newTree = (Tree*)malloc(sizeof(Tree));
    newTree->value = value;
    newTree->left = NULL;
    newTree->right = NULL;
    return newTree;
  }
  if(tree->value == value){
    return tree;
  }
  if(value < tree->value){
    tree->left = insert(tree->left, value);
  }else{
    tree->right = insert(tree->right, value);
  }
  return tree;
}

Tree* Root(Tree* tree, int value) 
{
  return insert(tree, value);
}

int contains(const Tree* tree, int value) {
  if(tree == NULL){
    return 0;
  }
  if(tree->value == value){
    return 1;
  }
  if(value < tree->value){
    return contains(tree->left, value);
  }
  return contains(tree->right, value);
}

Tree* extractMax(Tree* parent, Tree* tree) {
  if(tree->right != NULL){
    return extractMax(tree, tree->right);
  }
  if(tree == parent->right){
    parent->right = tree->left;
  }else{
    parent->left = tree->left;
  }
  return tree;
}

Tree* erase(Tree* tree, int value) {
  if(tree == NULL){
    return NULL;
  }
  if(value < tree->value){
    tree->left = erase(tree->left, value);
    return tree;
  }else if(tree->value < value){
    tree->right = erase(tree->right, value);
    return tree;
  }
  if(tree->left == NULL){
    Tree* temporary = tree->right;
    free(tree);
    return temporary;
  }
  Tree* other = extractMax(tree, tree->left);
  tree->value = other->value;
  free(other);
  return tree;
}

int max(int a, int b) {
  if(a < b){
    return b;
  }
  return a;
}

int height(const Tree* tree) {
  if(tree == NULL){
    return 0;
  }
  return max(height(tree->left), height(tree->right)) + 1;
}

void calcWidth(const Tree* tree, int lvl, int* width) {
  if(tree == NULL){
    return;
  }
  width[lvl] += 1;
  calcWidth(tree->left, lvl + 1, width);
  calcWidth(tree->right, lvl + 1, width);
}

void printInorder(const Tree* tree, int tab) {
  if(tree == NULL){
    return;
  }
  printInorder(tree->left, tab + 2);
  for(int i = 0; i < tab; ++i){
    putchar(' ');
  }
  printf("%d\n", tree->value);
  printInorder(tree->right, tab + 2);
}

int result(Tree* tree)
{
  int res = 0;
  if((tree->left == NULL)&&(tree->right == NULL))
  {
	res = 1;
  }
  else if(tree == NULL)
  {
	res = 0;
  }
  else
  {
	res = result(tree->left)+result(tree->right);
  }
  return res;
}

int main() {
  Tree* root = NULL;
  int value, res, n = 1000;
  char* q;
  q = (char*)malloc(n);
  while(scanf("%s%d", q, &value) == 2){
	if(q[0] == 'r')
	{
	  root = Root(root, value);
	  puts("---------------");
      printInorder(root, 0);
      puts("---------------");
    }
    else if(q[0] == '+'){
      root = insert(root, value);
      puts("---------------");
      printInorder(root, 0);
      puts("---------------");
    }else if(q[0] == '?'){
      if(contains(root, value)){
        puts("YES");
      }else{
        puts("NO");
      }
    }else if(q[0] == '-'){
      root = erase(root, value);
      puts("---------------");
      printInorder(root, 0);
      puts("---------------");
    }else if(q[0] == 'q'){
		res = result(root);
		printf("\n sheets: %d", res);
    }
  }
}

