#include <stdio.h>
#include <ctype.h>

int main()
{
  FILE *el;
  char *num;
  char c;
  int N = 0, i, t = 0;

  if(el = fopen("file.txt", "r") == NULL)
  {
    printf("Opening error");
    return -1;
  }else{
    while((c = fgetchar(el)) != EOF)
    {
      N++;
    }
    num = (char*)malloc(N * sizeof(int));
    for(i = 0; i < N; i++)
    {
      num[i] = fgetchar(el);
    }
    for(i = 0; i < N-1; i += t)
    {
      if(isalnum(num[i]))
      {
	while((num[i + t + 1] != ' ') || (num[i + t + 1] != EOF))
	{
	  if(isdigit(num[i])
	  {
	    if(isdigit(num[i+1]))
	    {
	      if(num[i] < num[i+1])
	      {
		
	      }
	    }
	    else if(num[i+1] == 'A')
	    {

	    }
	  }
	  else if(num[i] == 'A')
	  {
	    
	    
	  }
	}
	t++;
      }
    }
  }
  return 0;
}
