#include <stdio.h>
#include <stdlib.h>
#define MAX 10
#define STACK_OVERFLOW -100
#define STACK_UNDERFLOW -101

typedef int T;

typedef struct TStack {
	T data[MAX];
	size_t size;
}Stack;

void Push(Stack* stack, const T value)
{
	if(stack->size >= MAX)
	{
		exit(STACK_OVERFLOW);
	}
	stack->data[stack->size] = value;
	stack->size++;
}

T Pop(Stack* stack)
{
	if(stack->size == 0)
	{
		exit(STACK_UNDERFLOW);
	}
	stack->size--;
	return stack->data[stack->size];
}

T Peek(const Stack* stack)
{
	if(stack->size <= 0)
	{
		exit(STACK_UNDERFLOW);
	}
	return stack->data[stack->size - 1];
}

Stack* Sort(Stack* stack)
{
	int i;
	int t, swapped;
	do{
		swapped = 1;
		for(i = 1; i < stack->size; i++)
		{
			if(stack->data[i - 1] > stack->data[i])
			{
				t = stack->data[i];
				stack->data[i] = stack->data[i - 1];
				stack->data[i - 1] = t;
				swapped = 0;
			}
		}
	}while(swapped != 1);
	return stack;
}

void PrintValue(const T value)
{
	printf("%d", value);
}

void PrintStack(const Stack* stack, void (*PrintValue)(const T))
{
	int i;
	int len = stack->size - 1;
	printf("stack %ld >", stack->size);
	for(i = 0; i < len; i++)
	{
		PrintValue(stack->data[i]);
		putchar('|');
	}if(stack->size > 0)
	{
		PrintValue(stack->data[i]);
	}
	putchar('\n');
}

int main()
{
	Stack stack;
	stack.size = 0;
	char q[10];
	int value;

	while(scanf("%s%d", q, &value) == 2){
    if(q[0] == '+'){
      Push(&stack, value);
    }else if(q[0] == '-'){
      Pop(&stack);
    }else if(q[0] == '?'){
	  printf("\n%d\n", Peek(&stack));
    }else if(q[0] == 's'){
	  Sort(&stack);
	}else if(q[0] == 'p'){
      puts("---------------");
      PrintStack(&stack, PrintValue);
	  puts("---------------");
    }
  }

	return 0;
}
