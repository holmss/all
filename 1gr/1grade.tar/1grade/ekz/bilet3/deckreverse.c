#include <stdio.h>
#include <stdlib.h>
#define MAX 10
#define DECK_OVERFLOW -100
#define DECK_UNDERFLOW -101

typedef int T;

typedef struct TDeck {
	T data[MAX];
	size_t size;
}Deck;

void Push(Deck* deck, const T value)
{
	if(deck->size >= MAX)
	{
		exit(DECK_OVERFLOW);
	}
	deck->data[deck->size] = value;
	deck->size++;
}

T Pop(Deck* deck)
{
	if(deck->size == 0)
	{
		exit(STACK_UNDERFLOW);
	}
	deck->size--;
	return deck->data[deck->size];
}

T Peek(const Deck* deck)
{
	if(deck->size <= 0)
	{
		exit(STACK_UNDERFLOW);
	}
	return deck->data[deck->size - 1];
}

Deck* Sort(Deck* deck)
{
	int i;
	int t, swapped;
	do{
		swapped = 1;
		for(i = 1; i < deck->size; i++)
		{
			if(deck->data[i - 1] > deck->data[i])
			{
				t = deck->data[i];
				deck->data[i] = deck->data[i - 1];
				deck->data[i - 1] = t;
				swapped = 0;
			}
		}
	}while(swapped != 1);
	return deck;
}

void PrintValue(const T value)
{
	printf("%d", value);
}

void PrintStack(const Deck* deck, void (*PrintValue)(const T))
{
	int i;
	int len = deck->size - 1;
	printf("deck %ld >", deck->size);
	for(i = 0; i < len; i++)
	{
		PrintValue(deck->data[i]);
		putchar('|');
	}if(deck->size > 0)
	{
		PrintValue(deck->data[i]);
	}
	putchar('\n');
}

int main()
{
	Deck deck;
	deck.size = 0;
	char q[10];
	int value;

	while(scanf("%s%d", q, &value) == 2){
    if(q[0] == '+'){
      Push(&deck, value);
    }else if(q[0] == '-'){
      Pop(&deck);
    }else if(q[0] == '?'){
	  printf("\n%d\n", Peek(&deck));
    }else if(q[0] == 's'){
	  Sort(&deck);
	}else if(q[0] == 'p'){
      puts("---------------");
      PrintStack(&deck, PrintValue);
	  puts("---------------");
    }
  }

	return 0;
}
