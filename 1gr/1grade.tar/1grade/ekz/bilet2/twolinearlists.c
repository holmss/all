#include <stdio.h>

typedef struct dlc{
	int value;
	struct dlc *next;
	struct dlc *prev;
}list;

list *additem(list *l, int n)
{
	list *temp, *p;
	
	temp = (list*)malloc(sizeof(list));
	
	p = l->next; 
	l->next = temp; 
	temp->value = n; 
	temp->next = p; 
	temp->prev = l; 
	
	if (p != NULL)
		p->prev = temp;
	
	return(temp);
}

list *init(int n)
{
	list *node = (list*)malloc(sizeof(list));
	node->value = n;
	node->prev = NULL;
	node->next = NULL;

	return node;
}

list *rmitem(list *l, int value)
{	
	list *prev, *next;
	
	if(value != l->value)
	{
		return rmitem(l->next, value);
	}
	
	prev = l->prev;
	next = l->next; 
	
	if (prev != NULL)
		prev->next = l->next; 
		
	if (next != NULL)
		next->prev = l->prev;
	
	free(l);
	
	return prev;
}

list *rmroot (list *root)
{
	list *temp;
	
	temp = root->next;
	temp->prev = NULL;
	
	free(root);
	
	return(temp);
}

void print (const list *l)
{
	if(l == NULL){
    return;
  }
  
  printf("%d ", l->value);
  print (l->next);
  putchar('\n');
}

int amount(const list *l, list *p)
{
	int t = 1;
	
	if (p != NULL)
		t += amount(p, p->next);
	
	return t;
}

int compare (list *l, list *l2, int t) 
{
	if(l == NULL || l2 == NULL)
		return t;
		
	if (l->value == l2->value)
	{
		t = 0;
		compare(l->next, l2->next, t);
	}
	else 
		return 1;
}

int main()
{	
	list *root, *current;
	list *root2, *current2;
	char q[10];
	int value;
	
	while (scanf("%s%d", q, &value) == 2)
	{
		if(q[0] == 'r')
		{
			if(q[1] == '1')
			{
				root = init (value);
				current = root;
			}
			if(q[1] == '2')
			{
				root2 = init (value);
				current2 = root2;
			}
		}
		else if(q[0] == '+')
		{
			if(q[1] == '1')
			{
				current = additem (current, value);
			}
			if(q[1] == '2')
			{
				current2 = additem (current2, value);
			}
		}
		else if(q[0] == '-')
		{
			if(q[1] == '1')
			{
				rmitem (root->next, value);
			}
			if(q[1] == '2')
			{
				rmitem (root2->next, value);
			}
		}
		else if(q[0] == '#')
		{
			if(q[1] == '1')
			{
				root = rmroot (root);
			}
			if(q[1] == '2')
			{
				root2 = rmroot (root2);
			}
		}
		else if(q[0] == '?')
		{
			if(q[1] == '1')
			{
				list *p = root->next;
				printf("\nLENGTH: %d\n", amount (root, p));
			}
			if(q[1] == '2')
			{
				list *p2 = root2->next;
				printf("\nLENGTH: %d\n", amount (root2, p2));
			}
		}
		else if(q[0] == 'p')
		{
			print(root);
			putchar('\n');
			print(root2);
		}
		else if(q[0] == 'c')
		{
			if (compare(root, root2, 0) == 0)
				printf("the lists are the same\n");
			else 
				printf("the lists are different\n");
		}
	}

	
	return 0;
}
