#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>

typedef struct TTree{
	char value;
	struct TTree* child;
	struct TTree* sibling;
	int index;
}Tree;

Tree* createNode(char value, int index) {
  Tree* node = (Tree*)malloc(sizeof(Tree));
  node->value = value;
  node->child = NULL;
  node->sibling = NULL;
  node->index = index;
  return node;
}

Tree* createRoot(char value, int index) {
  return createNode(value, index);
}



int main()
{
	FILE* file = fopen("file.txt", "r")?fopen("file.txt","r"):stdin;
	char c;
	int n = 100, i = 0, j, f = 0, s, t;
	char* expr;
	char* temp;
	Tree* root = NULL;

	expr = (char*)malloc(n);
	temp = (char*)malloc(n);

	while((c = fgetc(file)) != EOF)
	{
		expr[i] = c;
		i++;
	}

	for(j = 0; j < i; j++)
	{
		printf("%c ", expr[j]);
	}

	for (j = 0; j < i; j++)
	{

		/*if((expr[j] == '+')&&(root == NULL))
		{
			root = createRoot(expr[j]);
			s = j;
			for(t = f; t < s; t++)
			{
				temp[t] = expr[t];
				printf("%c", temp[t]);
			}
			f = s;
			for(t = 0; t < s; t++)
			{
				if(temp[t] == '*')
				{
					root->child = createNode(temp[t]);
					root->child->child = createNode(temp[t-1]);
					root->child->child->sibling = createNode(temp[t+1]);
				}else{
					root->child = createNode('*');
					root->chid->child = createNode(temp[t]);
					root->chld->child->sibling = createNode('1');
				}
				root->child = root->child->sibling;
			}
			for(t = 0; t < s; t++)
			{
				temp[t] = '~';
				printf("%c", temp[t]);
			}
		}*/
		if((expr[j] == '+')&&(root == NULL))
		{
			root = CreateRoot(expr[j], '0');
		}
		if((expr[j] == '*')
		if(isalnum(expr[j]))
		{
			root->child = CreateNode(expr[j], '2');
		}

	}

	free(expr);
	return 0;
}
