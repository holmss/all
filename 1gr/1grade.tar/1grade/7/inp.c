#include <stdio.h>
#include <errno.h>
#include <malloc.h>

void usage()
{
	perror("Usage: filename");
}

int** matralloc(size_t m, size_t n)
{
	int** matrix = (int**)malloc(m*sizeof(int*));
	for(int i = 0; i < m; i++)
	{
		matrix[i] = (int*)malloc(n*sizeof(int));
	}
	return matrix;
}

int main(int argc, char* argv[])
{
	if(argc != 2)
	{
		usage();
		return 1;
	}

	FILE* inp = fopen(argv[1], "wb");
	int m, n;
	int i, j, k, t;
	int** matrix;

	if(!inp)
	{
		perror("Can`t open file");
		return 2;
	}

	//запись матрицы в файл----------------------------

	puts("Enter row and column number:\n");
	scanf("%d", &m);
	scanf("%d", &n);

	if(n * m > 100)
	{
		perror("item limit exceeded: 100");
		return 3;
	}

	matrix = matralloc(m, n);

	puts("Enter the values:\n");

	for(i = 0; i < m; i++)
	{
		for(j = 0; j < n; j++)
		{
			scanf("%d", &k);
			matrix[i][j] = k;
		}
	}
	
	for(i = 0; i < m; i++)
	{
		for(j = 0; j < n; j++)
		{
			fprintf(inp, "%d", matrix[i][j]);
		}
		fputc('\n', inp);
	}

	//----------------------------------------------------
	
	fclose(inp);
	return 0;
}
