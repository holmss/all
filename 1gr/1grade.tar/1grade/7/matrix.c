#include <stdio.h>
#include <errno.h>
#include <ctype.h>
#include <math.h>

void usage()
{
	printf("Usage: filename\n");
}

void output(int *CIP, int *PI, int *YE, int i, int j) {
	int a;
	
	printf("Matrix: \n");
	
	for (a = 1; a < i; ++a)
		printf("%2d ", CIP[a]);
		
	printf("\n");
	
	for (a = 1; a < j+1; ++a)
		printf("%2d ", PI[a]);
		
	printf("\n");
	
	for (a = 1; a < j; ++a)
		printf("%2d ", YE[a]);
		
	printf("\n");
}

void moutput(int *CIP, int *PI, int *YE, int mi, int mj)
{
	int i, k;
	
	printf("True Matrix:\n");
	
	for (i = 1; i < mi; ++i) {
		if (CIP[i] == 0) {
			for (k = 1; k < mj; ++k)
				printf("%2d ", 0);
				
			printf("\n");
		}
		else {
			
			int ind = CIP[i];
				
			for (k = 1; k < PI[ind]-1; ++k)
				printf("%2d ", YE[k]);
				
			
			printf("\n");
			
			
		}
	}
}

void input(FILE *inp, int *CIP, int *PI, int *YE, int *i, int *j) {
	char *line = malloc(1000);
	int   nol;
	
	for (nol = 1; fgets(line, 1000, inp); nol++)
	{
		int tmp, n, offset, col = 0;
		int wasnn = -1;
		
		for (offset = 0; sscanf(line + offset, "%d%n", &tmp, &n) == 1; offset += n, col++)
			if (tmp) {
				if (wasnn <= 0)
					wasnn = *j;
					
				printf("tmp = %d\n", tmp);
				PI[ *j]   = col;
				YE[(*j)++] = tmp;
			}
			
		CIP[nol] = wasnn >= 0 ? wasnn : 0;

		PI[*j + 1] = 0;
	}
	*i = nol;
	
	free(line);
	
	PI[(*j)+1] = 0;
}

int getimax(int *YE, int j) {
	int t, imax = 1;
	
	for (t = 2; t < j; ++t)
		if (YE[imax] < YE[t])
			imax = t;
			
	return imax;
}

int main(int argc, int* argv[])
{
	if (argc != 2)
	{
		usage();
		return 1;
	}
	
	FILE *inp = fopen(argv[1], "r");
	int   i   = 0;
	int   c, p;
	int   imin = 0, j = 1, k = 1, t = 0, s = 0;
	int  *CIP;
	int  *PI;
	int  *YE;

	if(!inp)
	{
		perror("No such file");
		return 2;
	}

	CIP = (int *)malloc(100);
	PI  = (int *)malloc(100);
	YE  = (int *)malloc(100);

	input (inp, CIP, PI, YE, &i, &j);

	output(CIP, PI, YE, i, j);
	moutput(CIP, PI, YE, i, j);

	//здесь заканчивается реализация схемы размещения и начинается поиск максимума и всё такое прочее

	int max;
	int imax;
	
	imax = getimax(YE, j);
	
	max = YE[imax];
		
	for (t = 0; t < i; ) {
		int ifound = 0, m;
		int first, second;
		
		while (!CIP[t] && t < i)
			++t;
			
		first = CIP[t++];
		
		while (!CIP[t] && t < i)
			++t;
			
		second = CIP[t++];
		
		if (!second)
			second = j;
		
		for (m = first; m < second; ++m)
			if (YE[m] == max) {
				ifound = 1;
				break;
			}
		
		if (ifound) 
			for (m = first; m < second; ++m)
				YE[m] /= max;
		
	}

	output(CIP, PI, YE, i, j);
	moutput(CIP, PI, YE, i, j);

	fclose(inp);
	
	return 0;
}
