#include <stdio.h>
#include <errno.h>
#include <ctype.h>
#include <math.h>

void usage()
{
	printf("Usage: filename\n");
}

int main(int argc, char* argv[])
{
	if(argc != 2)
	{
		usage();
		return 1;
	}
	
	FILE* inp = fopen(argv[1], "r");
	char c, p;
	int  i = 0, imin = 0, j = 1, k = 1, t = 0, s = 0;
	int* CIP;
	int* PI;
	char* YE;

	if(!inp)
	{
		perror("No such file");
		return 2;
	}

	CIP = (int*)malloc(100);
	PI  = (int*)malloc(100);
	YE  = (char*)malloc(100);

	//вывод и проверка матрицы на целочисленность-----------------------
	while((c = fgetc(inp)) != EOF)
	{
		if((!isdigit(c)) && (c != ' ') && (c != '\n'))
		{
			perror("Variable type: digit");
			return 3;
		}
		printf("%c", c);
	}

	putchar('\n');

	fseek(inp, 0, SEEK_SET);

	//запись матрицы в 3 вектора в соответствии с заданием--------------
	while((p = fgetc(inp)) != EOF)
	{
		/*if(p == ' ')
		{
			k++;
		}*/
		if(p == '\n')
		{
			k = 0;
			s++;
		}
		if(s > i)
		{
			CIP[i] = 0;
			i++;
		}
		else if((isdigit(p)) && (p != '0'))
		{
			if(i == s)
			{
				CIP[i] = j;
				i++;
			}
			PI[j] = k;
			YE[j] = p;
			j++;
		}
		k++;
	}
	PI[j+1] = 0;

	for(t = 0; t < i; t++)
	{
		printf("%d ", CIP[t]);
	}
	putchar('\n');

	for(t = 1; t < j+1; t++)
	{
		printf("%d ", PI[t]);
	}
	putchar('\n');

	for(t = 1; t < j; t++)
	{
		printf("%c ", YE[t]);
	}
	putchar('\n');

	//здесь заканчивается реализация схемы размещения и начинается поиск максимума и всё такое прочее

	char max = YE[1], max2 = '-1';
	int imax = 1, first, second = 0, r;

	while (imax < j){
		for (t = imax; t < j; t++)
		{
			if((YE[t] > max) && (max >= max2))
			{
				max = YE[t];
				imax = t;
			}

		}
	
		if(imax == second)
		{
			break;
		}
		
		for(t = i; t > 0; t--)
		{
			printf("cipt[%d] = %d\n", t, CIP[t]);
			if ((CIP[t] <= max) && (CIP[t] != 0))
			{
				first = CIP[t];
				break;
			}
		}
	
		for(t = first; t < i; t++)
		{
			if(CIP[t] != 0)
			{
				second = CIP[t];
				break;
			}
		}
	
		r = abs(second - first);
		
		for(t = first; t < second; t++)
		{
			YE[t] = (char)(YE[t] / max);
		}
		imax = second;
		max2 = max;
		max = YE[second];

	}

	for(t = 0; t < i; t++)
	{
		printf("%d ", CIP[t]);
	}
	putchar('\n');

	for(t = 1; t < j+1; t++)
	{
		printf("%d ", PI[t]);
	}
	putchar('\n');

	for(t = 1; t < j; t++)
	{
		printf("%c ", YE[t]);
	}
	putchar('\n');

	fclose(inp);
	return 0;
}
