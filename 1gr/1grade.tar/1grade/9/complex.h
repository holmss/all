#ifndef _COMPLEX_
#define _COMPLEX_

typedef struct 
    {
     double a;
	 double b;
    } complex_t;
 complex_t mul(complex_t x, complex_t y);
 complex_t compare(complex_t x, complex_t y);

#endif
