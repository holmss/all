#include "complex.h"
 
 complex_t mul(complex_t x, complex_t y)
 {
     complex_t t;
     t.a = x.a * y.a - x.b * y.b;
     t.b = x.a * y.b + x.b * y.a; 
     return t;
 }
 
 complex_t compare(complex_t x, complex_t y)
 {
	 if(x.a > y.a)
		return x;
	 else if(y.a > x.a)
		return y;
	 else if((x.a == y.a) && (x.b > y.b))
		return x;
	 else
		return y;
 }
