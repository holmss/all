#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <time.h>
#include "complex.h"

int n  = -1;
typedef struct 
{
	complex_t key;
	char string[100];
} line;

line L[100];

void prnt()
{
	puts("\nKey: \t\t\tString:");
	for (int i = 0; i<n; i++)
		printf("{%6lf, %6lf}│ %s", L[i].key.a, L[i].key.b, L[i].string);
}

void randomize()
{
	long a = time(0);
	srand(a);
}

void randLines()
{
	randomize();
	line temp;
	for (int i = 0; i<n; i++)
	{
		int j = rand() % n;
		temp = L[i];
		L[i] = L[j];
		L[j] = temp;
	}
}

void reverse()
{
	line temp;
	for (int i = 0; i<n / 2; i++)
	{
		temp = L[i];
		L[i] = L[n - i - 1];
		L[n - i - 1] = temp;
	}
}

void title()
{
	puts("Commands:\n\
		1:\t Print file\n\
		2:\t Sort file\n\
		3:\t Binary search\n\
		4:\t Randomize lines\n\
		5:\t Reverse lines\n\
		0:\t Exit");
	return;
}

void sort(int first, int last)
{
	if (first < last) 
	{
		int left = first, right = last;
		int m = (left + right) / 2;
		
		do 
		{
			while ((L[left].key.a < L[m].key.a) || ((L[left].key.a == L[m].key.a) && (L[left].key.b < L[m].key.b)))
				left++;
			while ((L[right].key.a > L[m].key.a) || ((L[right].key.a == L[m].key.a) && (L[right].key.b > L[m].key.b)))
				right--;
			
			if(left <= right)
			{
				line tmp[100];
				tmp[left] = L[left];
				L[left] = L[right];
				L[right] = tmp[left];
				left++;
				right--;
			}
		} while (left <= right);
		sort(first, right);
		sort(left, last);
	}
}

void bsrch(complex_t k)
{
	int m, left = 0, right = n - 1;
	while (left < right)
	{
		m = (left + right) / 2;
		if ((k.a > L[m].key.a) || ((k.a == L[m].key.a) && (k.b > L[m].key.b)))
			left = m + 1;
		else 
			right = m;
	}
	if ((k.a == L[left].key.a) && (k.b == L[left].key.b))
		printf("Key is found:\n{%lf, %lf} %s", k.a, k.b, L[left].string);
	else 
		puts("Key not found\n");
}

int main(int argc, char **argv)
{
	FILE *in;
	int input, ind = 0;
	complex_t k;
	
	if (argc > 1)
	{
		if(!(in = fopen(argv[1],"r")))
		{
			puts("Can\'t open");
			return 1;
		}
	}
	else if(!(in = fopen("inp1.txt","r")))
	{
		puts("Can\'t open");
		return 1;
	}
	
	while (!feof(in))
	{
		++n;
		fscanf(in, "%lf%lf", &L[n].key.a, &L[n].key.b);
		fgets(L[n].string, 100, in);
	}
	title();
	printf(">> ");
	
	while (scanf("%d",  &input) == 1)
	{
		switch(input)
		{
			case 1:
				{
				prnt();
				break;}
			case 2:{
				sort(0, n - 1);
				prnt();
				ind = 1;
				break;}
			case 3:{
				if (ind)
				{
					printf("Enter the key:");
					scanf("%lf%lf", &k.a, &k.b);
					bsrch(k);
				}
				else puts("Sort file first");
				break;}
			case 4:{
				randLines();
				prnt();
				break;}
			case 5:{
				reverse();
				prnt();
				break;}
			case 0:{
				fclose(in);
				return 0;}
			default:{
				puts("Wrong command");
				break;}
		}
		printf(">> ");
	}
	return 0;
}
